from router_main import dijkstra, print_paths

print_paths("F")